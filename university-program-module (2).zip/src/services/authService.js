const USERS_KEY = 'app_users';
const SESSION_KEY = 'app_session';

// The 6 roles defined in the requirement deck (Slide 3), with a short
// description of what each one can do in this module.
export const ROLES = [
  {
    id: 'superadmin',
    label: 'Super Admin',
    description: 'Full access to every module and setting.',
  },
  {
    id: 'univadmin',
    label: 'University Admin',
    description: 'Full CRUD on all programs across every department.',
  },
  {
    id: 'depthead',
    label: 'Department Head',
    description: 'Manage programs belonging to their own department only.',
  },
  {
    id: 'faculty',
    label: 'Faculty',
    description: 'View-only access to program records.',
  },
  {
    id: 'student',
    label: 'Student',
    description: 'View-only access to their enrolled program.',
  },
  {
    id: 'leadership',
    label: 'Leadership',
    description: 'Dashboard & analytics only — no program editing.',
  },
];

export const getRoleMeta = (roleId) => ROLES.find((r) => r.id === roleId) || ROLES[3];

const getUsers = () => {
  const data = localStorage.getItem(USERS_KEY);
  return data ? JSON.parse(data) : [];
};

const saveUsers = (users) => {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

const delay = (ms = 300) => new Promise((resolve) => setTimeout(resolve, ms));

export const authService = {
  signup: async ({ name, email, password, role = 'faculty', department = '' }) => {
    await delay();
    const users = getUsers();
    if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
      throw new Error('An account with this email already exists.');
    }
    const newUser = { id: Date.now().toString(), name, email, password, role, department };
    users.push(newUser);
    saveUsers(users);

    const session = {
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
      department: newUser.department,
    };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    return session;
  },

  login: async ({ email, password }) => {
    await delay();
    const users = getUsers();
    const user = users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );
    if (!user) {
      throw new Error('Invalid email or password.');
    }

    const session = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role || 'faculty',
      department: user.department || '',
    };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    return session;
  },

  // Quick demo login as any of the 6 roles — no password needed.
  // Lets a reviewer see how the UI adapts to each permission level.
  loginAsRole: async (roleId) => {
    await delay(150);
    const meta = getRoleMeta(roleId);
    const isDeptScoped = roleId === 'depthead' || roleId === 'student';

    const session = {
      id: `demo-${roleId}`,
      name: `Demo ${meta.label}`,
      email: `${roleId}@university.edu`,
      role: roleId,
      department: isDeptScoped ? 'Computer Science' : '',
    };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    return session;
  },

  logout: () => {
    localStorage.removeItem(SESSION_KEY);
  },

  getSession: () => {
    const data = localStorage.getItem(SESSION_KEY);
    return data ? JSON.parse(data) : null;
  },
};
