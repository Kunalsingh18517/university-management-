// Dummy backend for the Program Module.
// Single source of truth for program records — every page imports from here.
// Fields mirror the requirement deck (Slide 6: Program Fields & Validation).

const STORAGE_KEY = "programs_db";

const INITIAL_PROGRAMS = [];

// Duration (years) -> required Total Semesters, per Slide 6:
// "Total Semesters must match Duration (e.g. 3 yrs -> 6 sem, 4 yrs -> 8 sem)"
export const expectedSemesters = (durationYears) => {
  const n = Number(durationYears);
  if (!n || n <= 0) return null;
  return n * 2;
};

// Repairs older/broken records (e.g. saved with "_id" instead of "id",
// or missing an id entirely) so every record can always be looked up
// and deleted reliably.
const normalizeRecords = (data) => {
  let changed = false;

  const normalized = data.map((record) => {
    if (record.id) return record;
    changed = true;
    return {
      ...record,
      id: record._id || Date.now().toString() + Math.random().toString(16).slice(2),
    };
  });

  return { normalized, changed };
};

const getStoredData = () => {
  const data = localStorage.getItem(STORAGE_KEY);

  if (!data) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_PROGRAMS));
    return INITIAL_PROGRAMS;
  }

  let parsed;
  try {
    parsed = JSON.parse(data);
  } catch (err) {
    console.error("Corrupted programs_db, resetting to defaults:", err);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_PROGRAMS));
    return INITIAL_PROGRAMS;
  }

  const { normalized, changed } = normalizeRecords(parsed);
  if (changed) saveStoredData(normalized);

  return normalized;
};

const saveStoredData = (data) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};

const delay = (ms = 200) => new Promise((resolve) => setTimeout(resolve, ms));

export const dummyBackendService = {
  // Wipes all stored program records — used by Settings > "Reset all data".
  resetAllData: async () => {
    localStorage.removeItem(STORAGE_KEY);
    return { success: true };
  },

  getAll: async () => {
    await delay();
    return getStoredData().filter((program) => !program.isDeleted);
  },

  // Includes archived/soft-deleted records — used by the "Archived" filter.
  getAllIncludingArchived: async () => {
    await delay();
    return getStoredData();
  },

  getById: async (id) => {
    await delay();
    return getStoredData().find((p) => p.id === id) || null;
  },

  isCodeTaken: async (code, excludeId = null) => {
    await delay(50);
    const normalized = (code || "").trim().toLowerCase();
    return getStoredData().some(
      (p) => p.code.trim().toLowerCase() === normalized && p.id !== excludeId
    );
  },

  create: async (programData) => {
    await delay();
    const data = getStoredData();

    const codeTaken = data.some(
      (p) => p.code.trim().toLowerCase() === (programData.code || "").trim().toLowerCase()
    );
    if (codeTaken) throw new Error("Program Code must be unique — this code is already in use.");

    const now = new Date().toISOString();
    const newProgram = {
      ...programData,
      id: Date.now().toString(),
      isDeleted: false,
      deletedAt: null,
      createdAt: now,
      updatedAt: now,
    };
    data.push(newProgram);
    saveStoredData(data);
    return newProgram;
  },

  update: async (id, updatedData) => {
    await delay();
    if (!id) throw new Error("update() called without a valid id");

    const data = getStoredData();
    const index = data.findIndex((p) => p.id === id);
    if (index === -1) throw new Error("Program not found");

    const codeTaken = data.some(
      (p) =>
        p.id !== id &&
        p.code.trim().toLowerCase() === (updatedData.code || "").trim().toLowerCase()
    );
    if (codeTaken) throw new Error("Program Code must be unique — this code is already in use.");

    data[index] = {
      ...data[index],
      ...updatedData,
      id,
      updatedAt: new Date().toISOString(),
    };
    saveStoredData(data);
    return data[index];
  },

  // Soft delete / archive — per requirement Slide 5 & 7.
  delete: async (id) => {
    await delay();
    if (!id) throw new Error("delete() called without a valid id");

    const data = getStoredData();
    const index = data.findIndex((p) => p.id === id);
    if (index === -1) throw new Error("Program not found");

    data[index] = {
      ...data[index],
      status: "Archived",
      isDeleted: true,
      deletedAt: new Date().toISOString(),
    };
    saveStoredData(data);
    return { success: true, message: "Program archived successfully" };
  },

  // Restore a soft-deleted program (Slide 9 open question — implemented as yes).
  restore: async (id) => {
    await delay();
    const data = getStoredData();
    const index = data.findIndex((p) => p.id === id);
    if (index === -1) throw new Error("Program not found");

    data[index] = {
      ...data[index],
      status: "Inactive",
      isDeleted: false,
      deletedAt: null,
      updatedAt: new Date().toISOString(),
    };
    saveStoredData(data);
    return data[index];
  },
};
