import React, { useState, useEffect } from "react";
import ProgramListPage from "./pages/ProgramListPage";
import AddProgramPage from "./pages/AddProgramPage";
import EditProgramPage from "./pages/EditProgramPage";
import ProgramDetailsPage from "./pages/ProgramDetailsPage";
import DashboardPage from "./pages/DashboardPage";
import ReportsPage from "./pages/ReportsPage";
import SettingsPage from "./pages/SettingsPage";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import Sidebar, { NAV_BY_ROLE } from "./components/Sidebar";
import Topbar from "./components/Topbar";
import GlobalSearchModal from "./components/GlobalSearchModal";
import { authService } from "./services/authService";
import "./App.css";

function App() {
  const [authPage, setAuthPage] = useState("login");
  const [user, setUser] = useState(null);
  const [currentPage, setCurrentPage] = useState("dashboard");
  const [selectedProgramId, setSelectedProgramId] = useState(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    const session = authService.getSession();
    if (session) {
      setUser(session);
    }
  }, []);

  // Ctrl/Cmd+K opens global search from anywhere in the app.
  useEffect(() => {
    const handleKey = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, []);

  const navigateTo = (page, id = null) => {
    setCurrentPage(page);
    setSelectedProgramId(id);
    setSidebarOpen(false);
  };

  const handleLogout = () => {
    authService.logout();
    setUser(null);
    setAuthPage("login");
    setCurrentPage("dashboard");
  };

  const handleSwitchRole = async (roleId) => {
    const session = await authService.loginAsRole(roleId);
    setUser(session);
    setCurrentPage("dashboard");
  };

  if (!user) {
    return authPage === "login" ? (
      <LoginPage
        onLoginSuccess={(session) => setUser(session)}
        navigateToSignup={() => setAuthPage("signup")}
      />
    ) : (
      <SignupPage
        onSignupSuccess={(session) => setUser(session)}
        navigateToLogin={() => setAuthPage("login")}
      />
    );
  }

  // Guard: if the current role can't see a page (e.g. a view-only role
  // deep-linked into "add"), fall back to the dashboard instead of
  // rendering a page they shouldn't have access to.
  const allowedPages = NAV_BY_ROLE[user.role] || NAV_BY_ROLE.faculty;
  const pageToNavKey = { list: "programs", edit: "programs", details: "programs" };
  const effectivePage =
    currentPage === "dashboard" ||
    allowedPages.includes(pageToNavKey[currentPage] || currentPage)
      ? currentPage
      : "dashboard";

  const canCreate = ["superadmin", "univadmin", "depthead"].includes(user.role);

  return (
    <div className="app-container">
      <Sidebar
        user={user}
        currentPage={effectivePage}
        navigateTo={navigateTo}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <div className="lm-shell-main">
        <Topbar
          user={user}
          currentPage={effectivePage}
          navigateTo={navigateTo}
          onOpenSearch={() => setSearchOpen(true)}
          onLogout={handleLogout}
          onToggleSidebar={() => setSidebarOpen(true)}
          canCreate={canCreate}
        />

        <main className="app-main">
          {effectivePage === "dashboard" && (
            <DashboardPage user={user} navigateTo={navigateTo} canCreate={canCreate} />
          )}

          {effectivePage === "list" && (
            <ProgramListPage navigateTo={navigateTo} user={user} />
          )}

          {effectivePage === "add" && canCreate && (
            <AddProgramPage onNavigate={navigateTo} user={user} />
          )}

          {effectivePage === "edit" && (
            <EditProgramPage
              programId={selectedProgramId}
              navigateTo={navigateTo}
              user={user}
            />
          )}

          {effectivePage === "details" && (
            <ProgramDetailsPage
              programId={selectedProgramId}
              navigateTo={navigateTo}
              user={user}
            />
          )}

          {effectivePage === "reports" && <ReportsPage user={user} />}

          {effectivePage === "settings" && (
            <SettingsPage user={user} onSwitchRole={handleSwitchRole} />
          )}
        </main>

        <footer className="app-footer">
          <p>
            © {new Date().getFullYear()} University Program Module. All
            Rights Reserved.
          </p>
        </footer>
      </div>

      <GlobalSearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        navigateTo={navigateTo}
      />
    </div>
  );
}
export default App;
