import React, { useState, useEffect } from "react";
import { dummyBackendService } from "../services/dummyBackendService";
import SearchBar from "../components/SearchBar";
import FilterPanel from "../components/FilterPanel";
import StatisticsCards from "../components/StatisticsCards";
import ProgramTable from "../components/ProgramTable";
import DeleteConfirmationDialog from "../components/DeleteConfirmationDialog";

export default function ProgramListPage({ navigateTo, user }) {
  const [programs, setPrograms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDept, setSelectedDept] = useState("All");
  const [selectedStatus, setSelectedStatus] = useState("All");
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState("");

  const isDeptScoped = user?.role === "depthead" || user?.role === "student";
  const canEdit = user?.role === "superadmin" || user?.role === "univadmin" || user?.role === "depthead";
  const canDelete = canEdit;
  const canCreate = canEdit;
  
  // Pagination
const [currentPage, setCurrentPage] = useState(1);
const programsPerPage = 5;

// Sorting
const [sortField, setSortField] = useState("name");
const [sortOrder, setSortOrder] = useState("asc");

  const fetchPrograms = async () => {
    setLoading(true);

    try {
      const data = await dummyBackendService.getAllIncludingArchived();
      const scoped = isDeptScoped ? data.filter((p) => p.department === user.department) : data;
      setPrograms(scoped || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
useEffect(() => {
  fetchPrograms();
}, []);

  const handleRestore = async (id) => {
    try {
      await dummyBackendService.restore(id);
      fetchPrograms();
    } catch (err) {
      setDeleteError("Failed to restore program.");
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;

    setIsDeleting(true);
    setDeleteError("");

    try {
      await dummyBackendService.delete(deleteTarget.id);
      setDeleteTarget(null);
      fetchPrograms();
    } catch (err) {
      setDeleteError("Failed to delete program.");
    } finally {
      setIsDeleting(false);
    }
  };

  const departments = [...new Set(programs.map((p) => p.department))];

  const filteredPrograms = programs.filter((p) => {
    
    const term = searchTerm.toLowerCase();

    const matchesSearch =
      p.name.toLowerCase().includes(term) ||
      p.code.toLowerCase().includes(term) ||
      (p.description && p.description.toLowerCase().includes(term));

    const matchesDept = selectedDept === "All" || p.department === selectedDept;

    const matchesStatus = selectedStatus === "All" || p.status === selectedStatus;

    const matchesArchiveVisibility =
      selectedStatus === "Archived" ? p.isDeleted : !p.isDeleted;

   return (
  matchesArchiveVisibility &&
  matchesSearch &&
  matchesDept &&
  matchesStatus
);
  });
   // Sorting Logic
const sortedPrograms = [...filteredPrograms].sort((a, b) => {
  let first = a[sortField];
  let second = b[sortField];

  if (typeof first === "string") first = first.toLowerCase();
  if (typeof second === "string") second = second.toLowerCase();

  if (first < second) return sortOrder === "asc" ? -1 : 1;
  if (first > second) return sortOrder === "asc" ? 1 : -1;

  return 0;
});

// Pagination Logic
const indexOfLastProgram = currentPage * programsPerPage;
const indexOfFirstProgram = indexOfLastProgram - programsPerPage;

const currentPrograms = sortedPrograms.slice(
  indexOfFirstProgram,
  indexOfLastProgram
);

const totalPages = Math.ceil(
  sortedPrograms.length / programsPerPage
);

// Reset page when search/filter changes
useEffect(() => {
  setCurrentPage(1);
}, [searchTerm, selectedDept, selectedStatus]);
  return (
    <div className="upm-page">
      <style>{`
        .upm-page {
          max-width: 1180px;
          margin: 0 auto;
          padding: 32px 24px 64px;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        }

        .upm-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 24px;
          padding-bottom: 22px;
          margin-bottom: 26px;
          border-bottom: 1px solid #e7e0d2;
        }

        .upm-header-icon {
          width: 42px;
          height: 42px;
          border-radius: 50%;
          border: 1.5px solid #1e2a44;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }
        .upm-header-icon svg {
          width: 20px;
          height: 20px;
          stroke: #1e2a44;
          fill: none;
          stroke-width: 1.7;
          stroke-linecap: round;
          stroke-linejoin: round;
        }

        .upm-header-titlewrap {
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .upm-header h1 {
          font-family: Georgia, "Times New Roman", serif;
          font-size: 28px;
          font-weight: 700;
          color: #241d16;
          margin: 0;
        }

        .upm-header p {
          margin: 8px 0 0;
          color: #6b6156;
          font-size: 14.5px;
          max-width: 560px;
        }

        .upm-btn-primary {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #1e2a44;
          color: #fdfbf7;
          border: none;
          border-radius: 5px;
          padding: 11px 18px;
          font-size: 14px;
          font-weight: 600;
          letter-spacing: 0.01em;
          cursor: pointer;
          transition: background 0.2s ease, transform 0.2s ease;
          white-space: nowrap;
        }
        .upm-btn-primary:hover {
          background: #2a3a5c;
          transform: translateY(-1px);
        }
        .upm-btn-primary svg {
          width: 15px;
          height: 15px;
          stroke: currentColor;
          fill: none;
          stroke-width: 2.2;
          stroke-linecap: round;
          stroke-linejoin: round;
        }

        .upm-stats-block {
          margin-bottom: 28px;
        }

        .upm-filter-panel {
          display: flex;
          flex-wrap: wrap;
          gap: 14px;
          align-items: center;
          background: #fffdf9;
          border: 1px solid #e7e0d2;
          border-radius: 6px;
          padding: 16px 18px;
          margin-bottom: 22px;
        }

        .upm-table-container {
          background: #fffdf9;
          border: 1px solid #e7e0d2;
          border-radius: 6px;
          overflow: hidden;
        }

        .upm-loading {
          padding: 48px 0;
          text-align: center;
          color: #6b6156;
          font-size: 14.5px;
          font-style: italic;
        }

        .upm-alert-error {
          margin-top: 16px;
          padding: 12px 16px;
          border-radius: 5px;
          background: #fbeceb;
          border: 1px solid #e0b3b0;
          color: #8c2f39;
          font-size: 14px;
        }
          @keyframes spin {
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
}
      `}</style>

      {/* Dashboard Header */}
      <div className="upm-header">
        <div className="upm-header-titlewrap">
          <div className="upm-header-icon">
            <svg viewBox="0 0 24 24">
              <path d="m2 9 10-5 10 5-10 5-10-5Z" />
              <path d="M6 12v5c0 1.3 2.7 3 6 3s6-1.7 6-3v-5" />
              <path d="M22 9v6" />
            </svg>
          </div>
          <div>
            <h1>Academic Programs Dashboard</h1>
            <p>
              Manage all university programs, admissions and curriculum from
              one centralized dashboard.
            </p>
          </div>
        </div>

        {canCreate && (
          <button className="upm-btn-primary" onClick={() => navigateTo("add")}>
            <svg viewBox="0 0 24 24">
              <path d="M12 5v14M5 12h14" />
            </svg>
            Add Program
          </button>
        )}
      </div>

      {/* Statistics */}
      <div className="upm-stats-block">
      <StatisticsCards programs={filteredPrograms} />
      </div>

      {/* Search & Filters */}
      <div className="upm-filter-panel">
        <SearchBar searchTerm={searchTerm} onSearchChange={setSearchTerm} />

        <FilterPanel
          selectedDept={selectedDept}
          onDeptChange={setSelectedDept}
          selectedStatus={selectedStatus}
          onStatusChange={setSelectedStatus}
          departments={departments}
        />
      </div>

      {/* Programs Table */}
<div className="upm-table-container">
  {loading ? (
    <div
      className="upm-loading"
      style={{
        padding: "60px",
        textAlign: "center",
      }}
    >
      <div
        style={{
          width: "45px",
          height: "45px",
          border: "5px solid #e5e7eb",
          borderTop: "5px solid #2563eb",
          borderRadius: "50%",
          margin: "0 auto 20px",
          animation: "spin 1s linear infinite",
        
        }}
      ></div>

      <h3>Loading Programs...</h3>

      <p>Please wait while we fetch the latest records.</p>
    </div>
  ) : (
        <ProgramTable
  programs={currentPrograms}
  sortField={sortField}
  sortOrder={sortOrder}
  onSort={(field) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("asc");
    }
  }}
  onView={(id) => navigateTo("details", id)}
  onEdit={(id) => navigateTo("edit", id)}
  onDeleteTrigger={(program) => setDeleteTarget(program)}
  onRestore={handleRestore}
  canEdit={canEdit}
  canDelete={canDelete}
/>
        )}
      </div>
      {totalPages > 1 && (
      <div
  style={{
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    gap: "10px",
    marginTop: "25px",
    flexWrap: "wrap",
  }}
>
  <button
    className="btn-view"
    disabled={currentPage === 1}
    onClick={() => setCurrentPage(currentPage - 1)}
  >
    ← Previous
  </button>

  {[...Array(totalPages)].map((_, index) => (
    <button
      key={index}
      onClick={() => setCurrentPage(index + 1)}
      style={{
        padding: "8px 14px",
        borderRadius: "8px",
        border: "none",
        cursor: "pointer",
        background:
          currentPage === index + 1
            ? "#2563eb"
            : "#e5e7eb",
        color:
          currentPage === index + 1
            ? "#fff"
            : "#000",
      }}
    >
      {index + 1}
    </button>
  ))}

  <button
    className="btn-view"
    disabled={currentPage === totalPages}
    onClick={() => setCurrentPage(currentPage + 1)}
  >
    Next →
  </button>
</div>
)}

      {deleteError && <div className="upm-alert-error">{deleteError}</div>}

      <DeleteConfirmationDialog
        isOpen={!!deleteTarget}
        programName={deleteTarget?.name || ""}
        onConfirm={handleDeleteConfirm}
        onCancel={() => {
          setDeleteTarget(null);
          setDeleteError("");
        }}
        isLoading={isDeleting}
      />
    </div>
  );
}
