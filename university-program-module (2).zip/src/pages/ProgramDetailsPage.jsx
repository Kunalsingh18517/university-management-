import React, { useEffect, useState } from 'react';
import { dummyBackendService } from '../services/dummyBackendService';

export default function ProgramDetailsPage({ programId, navigateTo, user }) {
  const [program, setProgram] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProgram = async () => {
      try {
        const data = await dummyBackendService.getById(programId);
        setProgram(data);
      } catch (error) {
        console.error("Error loading program:", error);
      } finally {
        setLoading(false);
      }
    };
    if (programId) fetchProgram();
  }, [programId]);

  if (loading) return <div style={{ padding: '30px', textAlign: 'center', color: '#666' }}>Loading program details...</div>;
  if (!program) return <div style={{ padding: '30px', textAlign: 'center', color: 'red' }}>Program not found.</div>;

  const canEdit = user?.role === 'superadmin' || user?.role === 'univadmin' || user?.role === 'depthead';

  // Calculate percentage fill metric for display metrics bar
  const capNum = Number(program.capacity || 0);
  const enrNum = Number(program.enrolled || 0);
  const fillPercentage = capNum > 0 ? Math.min(Math.round((enrNum / capNum) * 100), 100) : 0;

  const statusColors = {
    Active: { bg: '#e2f7e7', color: '#155724' },
    Inactive: { bg: '#fff3cd', color: '#7a5b00' },
    Archived: { bg: '#fff0f0', color: '#721c24' },
  };
  const statusStyle = statusColors[program.status] || statusColors.Active;

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', fontFamily: 'var(--font-body)' }}>
      <button 
        onClick={() => navigateTo('list')} 
        style={{ marginBottom: '20px', padding: '8px 16px', border: '1px solid var(--line)', background: '#fff', borderRadius: '4px', cursor: 'pointer', fontWeight: '500' }}
      >
        ← Back to Programs
      </button>

      <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0 4px 20px rgba(0,0,0,0.08)', overflow: 'hidden' }}>
        <div style={{ background: 'linear-gradient(135deg, var(--ink) 0%, var(--ink-hover) 100%)', padding: '30px', color: 'white' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '12px' }}>
            <div>
              <span style={{ textTransform: 'uppercase', fontSize: '12px', letterSpacing: '1px', background: 'rgba(255,255,255,0.2)', padding: '4px 8px', borderRadius: '4px', fontWeight: '600' }}>
                {program.code} — {program.level}
              </span>
              <h2 style={{ margin: '10px 0 5px 0', fontSize: '26px', fontWeight: '600' }}>{program.name}</h2>
              <p style={{ margin: 0, opacity: 0.85, fontSize: '15px' }}>Department of {program.department}</p>
              {program.coordinator && (
                <p style={{ margin: '4px 0 0', opacity: 0.85, fontSize: '13.5px' }}>Coordinator: {program.coordinator}</p>
              )}
            </div>
            <span style={{
              padding: '6px 14px', borderRadius: '20px', fontSize: '13px', fontWeight: 'bold',
              backgroundColor: statusStyle.bg, color: statusStyle.color,
            }}>
              ● {program.status}
            </span>
          </div>
        </div>

        <div style={{ padding: '30px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '20px', marginBottom: '30px' }}>
            <div style={{ background: 'var(--parchment)', padding: '15px', borderRadius: '8px', borderLeft: '4px solid var(--ink)' }}>
              <span style={{ fontSize: '12px', color: '#666', textTransform: 'uppercase' }}>Duration</span>
              <p style={{ margin: '5px 0 0 0', fontSize: '18px', fontWeight: 'bold' }}>{program.duration} Years</p>
            </div>
            <div style={{ background: 'var(--parchment)', padding: '15px', borderRadius: '8px', borderLeft: '4px solid #17a2b8' }}>
              <span style={{ fontSize: '12px', color: '#666', textTransform: 'uppercase' }}>Total Semesters</span>
              <p style={{ margin: '5px 0 0 0', fontSize: '18px', fontWeight: 'bold' }}>{program.totalSemesters || '—'}</p>
            </div>
            <div style={{ background: 'var(--parchment)', padding: '15px', borderRadius: '8px', borderLeft: '4px solid var(--brass)' }}>
              <span style={{ fontSize: '12px', color: '#666', textTransform: 'uppercase' }}>Active Courses</span>
              <p style={{ margin: '5px 0 0 0', fontSize: '18px', fontWeight: 'bold' }}>{program.activeCourses || '0'}</p>
            </div>
            <div style={{ background: 'var(--parchment)', padding: '15px', borderRadius: '8px', borderLeft: '4px solid #6f42c1' }}>
              <span style={{ fontSize: '12px', color: '#666', textTransform: 'uppercase' }}>Enrollment</span>
              <p style={{ margin: '5px 0 0 0', fontSize: '18px', fontWeight: 'bold' }}>{program.enrolled} / {program.capacity}</p>
            </div>
          </div>

          <div style={{ marginBottom: '30px', background: 'var(--parchment)', padding: '20px', borderRadius: '8px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px', fontSize: '14px', fontWeight: '600' }}>
              <span>Enrollment Fill Rate</span>
              <span style={{ color: 'var(--ink)' }}>{fillPercentage}% filled</span>
            </div>
            <div style={{ width: '100%', height: '10px', backgroundColor: '#dee2e6', borderRadius: '5px', overflow: 'hidden' }}>
              <div style={{ width: `${fillPercentage}%`, height: '100%', backgroundColor: 'var(--ink)', borderRadius: '5px', transition: 'width 0.5s ease' }}></div>
            </div>
          </div>

          <div style={{ marginBottom: '30px' }}>
            <h4 style={{ margin: '0 0 10px 0', fontSize: '16px', color: 'var(--ink)', borderBottom: '1px solid #eee', paddingBottom: '5px' }}>Program Description</h4>
            <p style={{ margin: 0, color: '#555', lineHeight: '1.6', fontSize: '15px', whiteSpace: 'pre-line' }}>
              {program.description || 'No description has been provided for this program yet.'}
            </p>
          </div>

          {canEdit && (
            <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', borderTop: '1px solid #eee', paddingTop: '20px' }}>
              <button 
                onClick={() => navigateTo('edit', program.id)} 
                style={{ 
                  padding: '10px 24px', backgroundColor: 'var(--ink)', color: 'white', border: 'none', 
                  borderRadius: '4px', cursor: 'pointer', fontWeight: '600', fontSize: '14px' 
                }}
              >
                Edit Program
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
