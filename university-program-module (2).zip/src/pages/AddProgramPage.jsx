import React, { useState } from "react";
import ProgramForm from "../components/ProgramForm";
import { dummyBackendService } from "../services/dummyBackendService";

const AddProgramPage = ({ onNavigate, user }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  const lockDepartment = user?.role === "depthead" ? user.department : undefined;

  const handleSubmit = async (formData) => {
    setIsLoading(true);
    setError("");
    setSuccess("");

    try {
      await dummyBackendService.create(formData);

      setSuccess("Program created successfully!");

      setTimeout(() => {
        onNavigate("list");
      }, 1000);
    } catch (err) {
      setError(err.message || "Error creating program");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="page-container add-program-page">
      <div className="page-header">
        <h1>Add New Program</h1>
        <p>Create a new university program</p>
      </div>

      {error && <div className="alert alert-error">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}

      <div className="form-wrapper">
        <ProgramForm
          onSubmit={handleSubmit}
          onCancel={() => onNavigate("list")}
          lockDepartment={lockDepartment}
        />
      </div>
    </div>
  );
};

export default AddProgramPage;
