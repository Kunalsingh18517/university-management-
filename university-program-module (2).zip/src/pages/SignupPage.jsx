import React, { useState } from 'react';
import { authService, ROLES } from '../services/authService';

const DEPARTMENTS = [
  'Computer Science',
  'Business Administration',
  'Mechanical Engineering',
  'Electrical Engineering',
  'Mathematics',
  'Physics',
  'Humanities',
];

export default function SignupPage({ onSignupSuccess, navigateToLogin }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState('faculty');
  const [department, setDepartment] = useState('Computer Science');
  const [agreed, setAgreed] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const needsDepartment = role === 'depthead' || role === 'student';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!name || !email || !password || !confirmPassword) {
      setError('Please fill in all fields.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (!agreed) {
      setError('Please agree to the terms to continue.');
      return;
    }

    setIsLoading(true);
    try {
      const session = await authService.signup({
        name,
        email,
        password,
        role,
        department: needsDepartment ? department : '',
      });
      onSignupSuccess(session);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-card">
          <div className="auth-header">
            <h1>Create your account</h1>
            <p>Start managing your academic programs today</p>
          </div>

          {error && <div className="alert alert-error">{error}</div>}

          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Full name</label>
              <input type="text" autoComplete="off" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" />
            </div>
            <div className="form-group">
              <label>Email</label>
              <input type="email" autoComplete="off" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@university.edu" />
            </div>

            <div className="form-group">
              <label>Role</label>
              <select value={role} onChange={(e) => setRole(e.target.value)}>
                {ROLES.map((r) => (
                  <option key={r.id} value={r.id}>{r.label}</option>
                ))}
              </select>
            </div>

            {needsDepartment && (
              <div className="form-group">
                <label>Department</label>
                <select value={department} onChange={(e) => setDepartment(e.target.value)}>
                  {DEPARTMENTS.map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>
            )}

            <div className="form-group">
              <label>Password</label>
              <input type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 6 characters" />
            </div>
            <div className="form-group">
              <label>Confirm password</label>
              <input type="password" autoComplete="new-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Re-enter your password" />
            </div>

            <div className="checkbox-group">
              <input type="checkbox" checked={agreed} onChange={(e) => setAgreed(e.target.checked)} id="terms" />
              <label htmlFor="terms">I agree to the terms of service and privacy policy.</label>
            </div>

            <button type="submit" className="btn-primary auth-btn" disabled={isLoading}>
              {isLoading ? 'Creating account...' : 'Create account'}
            </button>
          </form>

          <p className="auth-footer">
            Already have an account?
            <span className="auth-link" onClick={navigateToLogin}> Sign in</span>
          </p>
        </div>

        <div className="auth-illustration">
          <div className="illustration-content">
            <h2>Join your institution's program hub</h2>
            <p>One dashboard for every academic program you manage.</p>
            <ul className="features-list">
              <li>Real-time enrollment statistics</li>
              <li>Fast search and filtering</li>
              <li>A clean, modern interface</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
