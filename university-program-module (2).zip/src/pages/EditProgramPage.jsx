import React, { useState, useEffect } from "react";
import ProgramForm from "../components/ProgramForm";
import { dummyBackendService } from "../services/dummyBackendService";

const EditProgramPage = ({ programId, navigateTo, user }) => {
  const [program, setProgram] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const loadProgram = async () => {
      try {
        const data = await dummyBackendService.getById(programId);

        if (data) {
          setProgram(data);
        } else {
          setError("Program not found");
        }
      } catch (err) {
        setError("Error loading program");
      }
    };

    loadProgram();
  }, [programId]);

  const handleSubmit = async (formData) => {
    setIsLoading(true);
    setError("");
    setSuccess("");

    try {
      await dummyBackendService.update(programId, formData);

      setSuccess("Program updated successfully!");

      setTimeout(() => {
        navigateTo("list");
      }, 1000);

    } catch (err) {
      setError(err.message || "An error occurred while updating the program");
    } finally {
      setIsLoading(false);
    }
  };

  if (!program) {
    return (
      <div className="page-container">
        <div className="alert alert-error">
          {error || "Loading..."}
        </div>
      </div>
    );
  }

  const lockDepartment = user?.role === "depthead" ? user.department : undefined;

  return (
    <div className="page-container edit-program-page">
      <div className="page-header">
        <h1>Edit Program</h1>
        <p>Update program information</p>
      </div>

      {error && (
        <div className="alert alert-error">
          {error}
        </div>
      )}

      {success && (
        <div className="alert alert-success">
          {success}
        </div>
      )}

      <div className="form-wrapper">
        <ProgramForm
          initialData={program}
          onSubmit={handleSubmit}
          onCancel={() => navigateTo("list")}
          lockDepartment={lockDepartment}
        />
      </div>
    </div>
  );
};

export default EditProgramPage;
