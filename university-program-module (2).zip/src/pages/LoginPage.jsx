import React, { useState } from 'react';
import { authService, ROLES } from '../services/authService';

export default function LoginPage({ onLoginSuccess, navigateToSignup }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showRoles, setShowRoles] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Please enter both email and password.');
      return;
    }

    setIsLoading(true);
    try {
      const session = await authService.login({ email, password });
      onLoginSuccess(session);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDemoLogin = async (roleId) => {
    setError('');
    setIsLoading(true);
    try {
      const session = await authService.loginAsRole(roleId);
      onLoginSuccess(session);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-card">
          <div className="auth-header">
            <h1>Welcome back</h1>
            <p>Sign in to manage your academic programs</p>
          </div>

          {error && <div className="alert alert-error">{error}</div>}

          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                autoComplete="off"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@university.edu"
                className={error ? 'input-error' : ''}
              />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                autoComplete="off"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className={error ? 'input-error' : ''}
              />
            </div>
            <button type="submit" className="btn-primary auth-btn" disabled={isLoading}>
              {isLoading ? 'Signing in...' : 'Sign in'}
            </button>
          </form>

          <button className="btn-demo" onClick={() => setShowRoles((v) => !v)} disabled={isLoading}>
            {showRoles ? 'Hide demo roles' : 'Continue with a demo role'}
          </button>

          {showRoles && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginTop: '10px' }}>
              {ROLES.map((role) => (
                <button
                  key={role.id}
                  type="button"
                  className="btn-cancel"
                  style={{ fontSize: '12.5px', padding: '9px 8px' }}
                  onClick={() => handleDemoLogin(role.id)}
                  disabled={isLoading}
                  title={role.description}
                >
                  {role.label}
                </button>
              ))}
            </div>
          )}

          <div className="auth-divider">or</div>

          <p className="auth-footer">
            Don't have an account?
            <span className="auth-link" onClick={navigateToSignup}> Sign up</span>
          </p>
        </div>

        <div className="auth-illustration">
          <div className="illustration-content">
            <h2>University Program Module</h2>
            <p>Manage your institution's academic programs in one place.</p>
            <ul className="features-list">
              <li>Role-based access for admins, department heads, faculty & students</li>
              <li>Track enrollment and active courses across every program</li>
              <li>Search, filter, add, edit and archive programs with ease</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
