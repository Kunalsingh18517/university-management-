import React, { useEffect, useState } from 'react';
import { dummyBackendService } from '../services/dummyBackendService';

const icons = {
  programs: (
    <>
      <path d="m2 9 10-5 10 5-10 5-10-5Z" />
      <path d="M6 12v5c0 1.3 2.7 3 6 3s6-1.7 6-3v-5" />
    </>
  ),
  students: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21c0-4 3.6-6 8-6s8 2 8 6" />
    </>
  ),
  courses: (
    <>
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <path d="M3 9h18" />
    </>
  ),
  pending: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 3" />
    </>
  ),
};

function timeAgo(iso) {
  if (!iso) return '';
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min${mins === 1 ? '' : 's'} ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs} hour${hrs === 1 ? '' : 's'} ago`;
  const days = Math.round(hrs / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
}

export default function DashboardPage({ user, navigateTo, canCreate }) {
  const [programs, setPrograms] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dummyBackendService
      .getAllIncludingArchived()
      .then(setPrograms)
      .catch(() => setPrograms([]))
      .finally(() => setLoading(false));
  }, []);

  const visible =
    user.role === 'depthead' || user.role === 'student'
      ? programs.filter((p) => p.department === user.department)
      : programs;

  const live = visible.filter((p) => !p.isDeleted);
  const totalPrograms = live.length;
  const totalStudents = live.reduce((sum, p) => sum + Number(p.enrolled || 0), 0);
  const activeCourses = live.reduce((sum, p) => sum + Number(p.activeCourses || 0), 0);
  const pending = live.filter((p) => p.status === 'Inactive').length;

  const cards = [
    { label: 'Total Programs', value: totalPrograms, icon: 'programs', delta: `${live.filter(p => p.status === 'Active').length} active` },
    { label: 'Total Students', value: totalStudents.toLocaleString(), icon: 'students', delta: 'across all programs' },
    { label: 'Active Courses', value: activeCourses.toLocaleString(), icon: 'courses', delta: 'offered this term' },
    { label: 'Needs Review', value: pending, icon: 'pending', delta: pending > 0 ? 'inactive programs' : 'all clear' },
  ];

  const byDept = Object.values(
    live.reduce((acc, p) => {
      acc[p.department] = acc[p.department] || { department: p.department, enrolled: 0 };
      acc[p.department].enrolled += Number(p.enrolled || 0);
      return acc;
    }, {})
  ).slice(0, 6);
  const maxEnrolled = Math.max(1, ...byDept.map((d) => d.enrolled));

  const recent = [...live]
    .sort((a, b) => new Date(b.updatedAt || b.createdAt) - new Date(a.updatedAt || a.createdAt))
    .slice(0, 5);

  return (
    <div className="lm-dash">
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, color: 'var(--charcoal)' }}>
          Welcome back, {user.name?.split(' ')[0] || 'there'}
        </h1>
        <p style={{ color: 'var(--slate)', fontSize: 13.5, marginTop: 4 }}>
          {user.role === 'depthead' || user.role === 'student'
            ? `Showing programs for ${user.department}.`
            : 'Key metrics across every department.'}
        </p>
      </div>

      {loading ? (
        <div className="lm-empty-note">Loading dashboard...</div>
      ) : (
        <>
          <div className="lm-dash-grid">
            {cards.map((c) => (
              <div className="lm-stat-card" key={c.label}>
                <div className="lm-stat-card-top">
                  <span className="lm-stat-label">{c.label}</span>
                  <div className="lm-stat-icon">
                    <svg viewBox="0 0 24 24">{icons[c.icon]}</svg>
                  </div>
                </div>
                <div className="lm-stat-value">{c.value}</div>
                <div className="lm-stat-delta neutral">{c.delta}</div>
              </div>
            ))}
          </div>

          <div className="lm-dash-columns">
            <div>
              <div className="lm-panel">
                <div className="lm-panel-title">Enrollment by Department</div>
                <div className="lm-panel-sub">Total enrolled students, current term</div>

                {byDept.length === 0 ? (
                  <div className="lm-empty-note">No program data yet.</div>
                ) : (
                  <div className="lm-bars">
                    {byDept.map((d) => (
                      <div className="lm-bar-col" key={d.department}>
                        <div
                          className="lm-bar"
                          style={{ height: `${Math.max(6, (d.enrolled / maxEnrolled) * 100)}%` }}
                          title={`${d.enrolled} students`}
                        />
                        <div className="lm-bar-label">{d.department}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="lm-panel">
                <div className="lm-panel-title">Recent Activity</div>
                <div className="lm-panel-sub">Latest changes to program records</div>

                {recent.length === 0 ? (
                  <div className="lm-empty-note">Nothing to show yet.</div>
                ) : (
                  recent.map((p) => (
                    <div className="lm-activity-item" key={p.id}>
                      <div
                        className="lm-activity-dot"
                        style={{
                          background:
                            p.status === 'Active'
                              ? 'var(--success)'
                              : p.status === 'Archived'
                              ? 'var(--danger)'
                              : 'var(--warning)',
                        }}
                      />
                      <div>
                        <div className="lm-activity-title">{p.name}</div>
                        <div className="lm-activity-sub">
                          {p.status} · updated {timeAgo(p.updatedAt)}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div>
              <div className="lm-panel">
                <div className="lm-panel-title">Quick Actions</div>
                <div className="lm-panel-sub">&nbsp;</div>

                {canCreate && (
                  <div className="lm-quick-action" onClick={() => navigateTo('add')}>
                    <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" /></svg>
                    Add Program
                  </div>
                )}
                <div className="lm-quick-action" onClick={() => navigateTo('list')}>
                  <svg viewBox="0 0 24 24">
                    <path d="m2 9 10-5 10 5-10 5-10-5Z" />
                    <path d="M6 12v5c0 1.3 2.7 3 6 3s6-1.7 6-3v-5" />
                  </svg>
                  View All Programs
                </div>
                <div className="lm-quick-action" onClick={() => navigateTo('reports')}>
                  <svg viewBox="0 0 24 24">
                    <path d="M3 3v18h18" />
                    <path d="M7 15l4-5 3 3 5-7" />
                  </svg>
                  Generate Report
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
