import React, { useState } from 'react';
import { ROLES } from '../services/authService';
import { dummyBackendService } from '../services/dummyBackendService';

export default function SettingsPage({ user, onSwitchRole }) {
  const [resetDone, setResetDone] = useState(false);

  const handleReset = async () => {
    const ok = window.confirm(
      'This will permanently delete every program record (including archived ones). Continue?'
    );
    if (!ok) return;
    await dummyBackendService.resetAllData();
    setResetDone(true);
    setTimeout(() => window.location.reload(), 600);
  };

  return (
    <div className="lm-dash">
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, color: 'var(--charcoal)' }}>Settings</h1>
        <p style={{ color: 'var(--slate)', fontSize: 13.5, marginTop: 4 }}>
          Account details and demo tools.
        </p>
      </div>

      <div className="lm-panel" style={{ maxWidth: 520 }}>
        <div className="lm-panel-title">Account</div>
        <div className="lm-panel-sub">&nbsp;</div>
        <div style={{ fontSize: 13.5, color: 'var(--charcoal)', lineHeight: 1.9 }}>
          <div><strong>Name:</strong> {user.name}</div>
          <div><strong>Email:</strong> {user.email}</div>
          <div><strong>Role:</strong> {user.role}</div>
          {user.department && <div><strong>Department:</strong> {user.department}</div>}
        </div>
      </div>

      <div className="lm-panel" style={{ maxWidth: 520 }}>
        <div className="lm-panel-title">Data</div>
        <div className="lm-panel-sub">
          Clear every program record stored in this browser and start with a clean, empty list.
        </div>
        <button
          type="button"
          className="btn-cancel"
          style={{ color: 'var(--danger)', borderColor: 'var(--danger)' }}
          onClick={handleReset}
        >
          {resetDone ? 'Cleared — reloading...' : 'Reset all program data'}
        </button>
      </div>

      <div className="lm-panel" style={{ maxWidth: 520 }}>
        <div className="lm-panel-title">Preview as a different role</div>
        <div className="lm-panel-sub">
          Switch instantly to see how the sidebar and permissions change per role.
        </div>
        {ROLES.map((r) => (
          <div
            key={r.id}
            className="lm-quick-action"
            style={r.id === user.role ? { borderColor: 'var(--ink)', background: 'var(--parchment)' } : {}}
            onClick={() => onSwitchRole(r.id)}
          >
            <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6" /></svg>
            <div>
              <div>{r.label}{r.id === user.role ? ' (current)' : ''}</div>
              <div style={{ fontWeight: 400, fontSize: 12, color: 'var(--slate)' }}>{r.description}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
