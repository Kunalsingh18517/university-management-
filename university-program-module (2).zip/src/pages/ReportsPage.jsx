import React, { useEffect, useState } from 'react';
import { dummyBackendService } from '../services/dummyBackendService';

export default function ReportsPage({ user }) {
  const [programs, setPrograms] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dummyBackendService
      .getAllIncludingArchived()
      .then(setPrograms)
      .catch(() => setPrograms([]))
      .finally(() => setLoading(false));
  }, []);

  const visible =
    user.role === 'depthead' || user.role === 'student'
      ? programs.filter((p) => p.department === user.department)
      : programs;

  const statusCounts = ['Active', 'Inactive', 'Archived'].map((status) => ({
    status,
    count: visible.filter((p) => p.status === status).length,
  }));
  const maxStatus = Math.max(1, ...statusCounts.map((s) => s.count));

  const byDept = Object.values(
    visible.reduce((acc, p) => {
      acc[p.department] = acc[p.department] || { department: p.department, count: 0, enrolled: 0 };
      acc[p.department].count += 1;
      acc[p.department].enrolled += Number(p.enrolled || 0);
      return acc;
    }, {})
  );

  return (
    <div className="lm-dash">
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, color: 'var(--charcoal)' }}>Reports</h1>
        <p style={{ color: 'var(--slate)', fontSize: 13.5, marginTop: 4 }}>
          Program distribution and enrollment summary.
        </p>
      </div>

      {loading ? (
        <div className="lm-empty-note">Loading report data...</div>
      ) : (
        <div className="lm-dash-columns">
          <div>
            <div className="lm-panel">
              <div className="lm-panel-title">Programs by Status</div>
              <div className="lm-panel-sub">Active, inactive and archived program counts</div>
              <div className="lm-bars">
                {statusCounts.map((s) => (
                  <div className="lm-bar-col" key={s.status}>
                    <div
                      className="lm-bar"
                      style={{
                        height: `${Math.max(6, (s.count / maxStatus) * 100)}%`,
                        background:
                          s.status === 'Active'
                            ? 'var(--success)'
                            : s.status === 'Archived'
                            ? 'var(--danger)'
                            : 'var(--warning)',
                      }}
                      title={`${s.count} programs`}
                    />
                    <div className="lm-bar-label">{s.status} ({s.count})</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div>
            <div className="lm-panel">
              <div className="lm-panel-title">By Department</div>
              <div className="lm-panel-sub">&nbsp;</div>
              {byDept.length === 0 ? (
                <div className="lm-empty-note">No data yet.</div>
              ) : (
                byDept.map((d) => (
                  <div className="lm-activity-item" key={d.department}>
                    <div className="lm-activity-dot" style={{ background: 'var(--ink)' }} />
                    <div>
                      <div className="lm-activity-title">{d.department}</div>
                      <div className="lm-activity-sub">
                        {d.count} program{d.count === 1 ? '' : 's'} · {d.enrolled} students
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
