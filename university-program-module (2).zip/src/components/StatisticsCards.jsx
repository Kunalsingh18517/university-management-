import React from "react";

/* Inline icons — no external icon library required */
const icons = {
  book: (
    <path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H12v20H6.5A2.5 2.5 0 0 1 4 19.5v-15Z M20 4.5A2.5 2.5 0 0 0 17.5 2H12v20h5.5a2.5 2.5 0 0 0 2.5-2.5v-15Z" />
  ),
  check: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="m8.5 12.5 2.5 2.5 5-5" />
    </>
  ),
  flag: (
    <>
      <path d="M6 3v18" />
      <path d="M6 4h11l-2.5 4L17 12H6" />
    </>
  ),
  cap: (
    <>
      <path d="m2 9 10-5 10 5-10 5-10-5Z" />
      <path d="M6 12v5c0 1.3 2.7 3 6 3s6-1.7 6-3v-5" />
      <path d="M22 9v6" />
    </>
  ),
};

export default function StatisticsCards({ programs }) {
  const total = programs.length;
  const active = programs.filter((p) => p.status === "Active").length;
  const inactive = programs.filter((p) => p.status === "Inactive").length;
  const totalEnrolled = programs.reduce(
    (sum, p) => sum + Number(p.enrolled || 0),
    0
  );

  const cards = [
    { label: "Total Programs", value: total, icon: "book", accent: "#1e2a44" },
    { label: "Active Programs", value: active, icon: "check", accent: "#2f6f4e" },
    { label: "Inactive Programs", value: inactive, icon: "flag", accent: "#8c2f39" },
    { label: "Total Students", value: totalEnrolled.toLocaleString(), icon: "cap", accent: "#b8892f" },
  ];

  return (
    <div className="upm-stats-grid">
      <style>{`
        .upm-stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 22px;
        }
        @media (max-width: 900px) {
          .upm-stats-grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 520px) {
          .upm-stats-grid { grid-template-columns: 1fr; }
        }

        .upm-card {
          position: relative;
          background: #fffdf9;
          border: 1px solid #e7e0d2;
          border-radius: 6px;
          padding: 22px 22px 20px;
          box-shadow: 0 1px 2px rgba(30, 42, 68, 0.04);
          transition: transform 0.25s ease, box-shadow 0.25s ease, border-color 0.25s ease;
          overflow: hidden;
        }
        .upm-card::before {
          content: "";
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 4px;
          background: var(--accent);
        }
        .upm-card::after {
          content: "";
          position: absolute;
          top: 6px; left: 0; right: 0;
          height: 1px;
          background: var(--accent);
          opacity: 0.35;
        }
        .upm-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 10px 24px rgba(30, 42, 68, 0.12);
        }

        .upm-card-top {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
        }

        .upm-eyebrow {
          font-family: Georgia, 'Times New Roman', serif;
          font-size: 12px;
          letter-spacing: 0.09em;
          text-transform: uppercase;
          color: #6b6156;
          margin: 0 0 10px;
        }

        .upm-value {
          font-family: Georgia, 'Times New Roman', serif;
          font-size: 40px;
          line-height: 1;
          font-weight: 700;
          color: #241d16;
          margin: 0;
        }

        .upm-badge {
          width: 38px;
          height: 38px;
          border-radius: 50%;
          border: 1.5px solid var(--accent);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          background: #fff;
          transition: transform 0.3s ease;
        }
        .upm-card:hover .upm-badge {
          transform: rotate(-8deg) scale(1.06);
        }
        .upm-badge svg {
          width: 18px;
          height: 18px;
          stroke: var(--accent);
          fill: none;
          stroke-width: 1.7;
          stroke-linecap: round;
          stroke-linejoin: round;
        }

        .upm-rule {
          margin-top: 14px;
          height: 1px;
          background: repeating-linear-gradient(
            to right,
            #d8cfbd 0, #d8cfbd 4px, transparent 4px, transparent 8px
          );
        }
      `}</style>

      {cards.map((card, i) => (
        <div className="upm-card" key={i} style={{ "--accent": card.accent }}>
          <div className="upm-card-top">
            <div>
              <p className="upm-eyebrow">{card.label}</p>
              <h2 className="upm-value">{card.value}</h2>
            </div>
            <div className="upm-badge">
              <svg viewBox="0 0 24 24">{icons[card.icon]}</svg>
            </div>
          </div>
          <div className="upm-rule" />
        </div>
      ))}
    </div>
  );
}