import React, { useEffect } from "react";

const DeleteConfirmationDialog = ({
  isOpen,
  programName,
  onConfirm,
  onCancel,
  isLoading,
}) => {
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e) => {
      if (e.key === "Escape" && !isLoading) {
        onCancel();
      }
    };

    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen, isLoading, onCancel]);

  if (!isOpen) return null;

  return (
    <div
      className="dialog-overlay"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isLoading) {
          onCancel();
        }
      }}
    >
      <div
        className="dialog-box"
        style={{
          maxWidth: "450px",
          width: "90%",
          background: "#fff",
          borderRadius: "15px",
          padding: "30px",
          textAlign: "center",
          boxShadow: "0 15px 40px rgba(0,0,0,.25)",
        }}
      >
        <div
          style={{
            fontSize: "55px",
            marginBottom: "15px",
          }}
        >
          ⚠️
        </div>

       <h2
  style={{
    marginBottom: "15px",
    color: "#f59e0b",
  }}
>
  📦 Archive Program
</h2>
        <p
  style={{
    color: "#555",
    lineHeight: "1.6",
    marginBottom: "25px",
  }}
>
  Are you sure you want to archive

  <br />

  <strong>{programName}</strong>

  ?

  <br />
  <br />

  You can restore this program later.
</p>
        <div
          style={{
            display: "flex",
            gap: "15px",
            justifyContent: "center",
            flexWrap: "wrap",
          }}
        >
          <button
            className="btn-cancel"
            disabled={isLoading}
            onClick={onCancel}
          >
            Cancel
          </button>

          <button
            className="btn-confirm-delete"
            disabled={isLoading}
            onClick={onConfirm}
          >
           {isLoading ? "Archiving..." : "Archive"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteConfirmationDialog;