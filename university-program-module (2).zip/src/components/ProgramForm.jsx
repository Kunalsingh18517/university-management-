import React, { useState, useEffect } from 'react';
import { dummyBackendService, expectedSemesters } from '../services/dummyBackendService';

const DEPARTMENTS = [
  'Computer Science',
  'Business Administration',
  'Mechanical Engineering',
  'Electrical Engineering',
  'Mathematics',
  'Physics',
  'Humanities',
];

const emptyForm = {
  name: '',
  shortName: '',
  code: '',
  department: '',
  level: 'Undergraduate',
  duration: '',
  totalSemesters: '',
  coordinator: '',
  capacity: '',
  enrolled: '',
  activeCourses: '',
  status: 'Active',
  description: '',
};

export default function ProgramForm({ initialData, onSubmit, onCancel, lockDepartment }) {
  const [formData, setFormData] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (initialData) {
      setFormData({ ...emptyForm, ...initialData });
    } else {
      setFormData(lockDepartment ? { ...emptyForm, department: lockDepartment } : emptyForm);
    }
  }, [initialData, lockDepartment]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = async () => {
    const newErrors = {};

    if (!formData.name.trim()) newErrors.name = 'Program Name is required.';
    if (!formData.code.trim()) newErrors.code = 'Program Code is required.';
    if (!formData.department.trim()) newErrors.department = 'Department is required.';

    if (!formData.duration || Number(formData.duration) <= 0) {
      newErrors.duration = 'Duration must be greater than 0.';
    }

    const expected = expectedSemesters(formData.duration);
    if (!formData.totalSemesters || Number(formData.totalSemesters) <= 0) {
      newErrors.totalSemesters = 'Total Semesters is required.';
    } else if (expected && Number(formData.totalSemesters) !== expected) {
      newErrors.totalSemesters = `For a ${formData.duration}-year program, Total Semesters must be ${expected}.`;
    }

    if (!formData.status) newErrors.status = 'Status is required.';

    if (formData.capacity && Number(formData.capacity) <= 0) {
      newErrors.capacity = 'Capacity must be greater than 0.';
    }
    if (Number(formData.enrolled || 0) > Number(formData.capacity || 0) && formData.capacity) {
      newErrors.enrolled = 'Enrolled students cannot exceed capacity.';
    }

    if (formData.code.trim()) {
      try {
        const taken = await dummyBackendService.isCodeTaken(formData.code, initialData?.id);
        if (taken) newErrors.code = 'This Program Code is already in use — codes must be unique.';
      } catch {
        // ignore lookup failure, server-side create/update will catch it too
      }
    }

    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    const newErrors = await validate();

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setIsSubmitting(false);
      return;
    }

    setErrors({});
    await onSubmit(formData);
    setIsSubmitting(false);
  };

  return (
    <form onSubmit={handleSubmit} className="upm-program-form">
      <div className="form-grid-2">
        <div className="form-group">
          <label>Program Name *</label>
          <input type="text" name="name" autoComplete="off" value={formData.name} onChange={handleChange} className={errors.name ? 'input-error' : ''} placeholder="e.g. Bachelor of Technology in Computer Science" />
          {errors.name && <p className="field-error">{errors.name}</p>}
        </div>

        <div className="form-group">
          <label>Short Name</label>
          <input type="text" name="shortName" autoComplete="off" value={formData.shortName} onChange={handleChange} placeholder="e.g. B.Tech" />
        </div>
      </div>

      <div className="form-grid-2">
        <div className="form-group">
          <label>Program Code *</label>
          <input type="text" name="code" autoComplete="off" value={formData.code} onChange={handleChange} className={errors.code ? 'input-error' : ''} placeholder="e.g. BTECH-CS" />
          {errors.code && <p className="field-error">{errors.code}</p>}
        </div>

        <div className="form-group">
          <label>Department *</label>
          <select
            name="department"
            value={formData.department}
            onChange={handleChange}
            disabled={!!lockDepartment}
            className={errors.department ? 'input-error' : ''}
          >
            <option value="">Select a department</option>
            {Array.from(new Set([...DEPARTMENTS, formData.department].filter(Boolean))).map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
          {errors.department && <p className="field-error">{errors.department}</p>}
        </div>
      </div>

      <div className="form-grid-2">
        <div className="form-group">
          <label>Level</label>
          <select name="level" value={formData.level} onChange={handleChange}>
            <option value="Undergraduate">Undergraduate</option>
            <option value="Postgraduate">Postgraduate</option>
            <option value="Doctoral">Doctoral</option>
            <option value="Diploma">Diploma</option>
          </select>
        </div>

        <div className="form-group">
          <label>Coordinator / HOD</label>
          <input type="text" name="coordinator" autoComplete="off" value={formData.coordinator} onChange={handleChange} placeholder="e.g. Dr. Sarah Jenkins" />
        </div>
      </div>

      <div className="form-grid-2">
        <div className="form-group">
          <label>Duration (years) *</label>
          <input type="number" name="duration" min="1" value={formData.duration} onChange={handleChange} className={errors.duration ? 'input-error' : ''} placeholder="e.g. 4" />
          {errors.duration && <p className="field-error">{errors.duration}</p>}
        </div>

        <div className="form-group">
          <label>Total Semesters *</label>
          <input type="number" name="totalSemesters" min="1" value={formData.totalSemesters} onChange={handleChange} className={errors.totalSemesters ? 'input-error' : ''} placeholder="Duration × 2" />
          {errors.totalSemesters && <p className="field-error">{errors.totalSemesters}</p>}
        </div>
      </div>

      <div className="form-grid-3">
        <div className="form-group">
          <label>Capacity</label>
          <input type="number" name="capacity" min="0" value={formData.capacity} onChange={handleChange} className={errors.capacity ? 'input-error' : ''} />
          {errors.capacity && <p className="field-error">{errors.capacity}</p>}
        </div>

        <div className="form-group">
          <label>Enrolled Students</label>
          <input type="number" name="enrolled" min="0" value={formData.enrolled} onChange={handleChange} className={errors.enrolled ? 'input-error' : ''} />
          {errors.enrolled && <p className="field-error">{errors.enrolled}</p>}
        </div>

        <div className="form-group">
          <label>Active Courses</label>
          <input type="number" name="activeCourses" min="0" value={formData.activeCourses} onChange={handleChange} />
        </div>
      </div>

      <div className="form-group">
        <label>Status *</label>
        <select name="status" value={formData.status} onChange={handleChange}>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
          <option value="Archived">Archived</option>
        </select>
      </div>

      <div className="form-group">
        <label>Description</label>
        <textarea name="description" value={formData.description} onChange={handleChange} rows={4} placeholder="Brief overview of the program's scope and focus." />
      </div>

      <div className="form-actions">
        <button type="button" className="btn-cancel" onClick={onCancel} disabled={isSubmitting}>
          Cancel
        </button>
        <button type="submit" className="btn-primary" disabled={isSubmitting}>
          {isSubmitting ? 'Saving...' : 'Save Program'}
        </button>
      </div>
    </form>
  );
}
