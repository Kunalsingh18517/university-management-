import React from 'react';
import { getRoleMeta } from '../services/authService';

const icons = {
  dashboard: (
    <>
      <rect x="3" y="3" width="7" height="9" rx="1.5" />
      <rect x="14" y="3" width="7" height="5" rx="1.5" />
      <rect x="14" y="12" width="7" height="9" rx="1.5" />
      <rect x="3" y="16" width="7" height="5" rx="1.5" />
    </>
  ),
  programs: (
    <>
      <path d="m2 9 10-5 10 5-10 5-10-5Z" />
      <path d="M6 12v5c0 1.3 2.7 3 6 3s6-1.7 6-3v-5" />
      <path d="M22 9v6" />
    </>
  ),
  add: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 8v8M8 12h8" />
    </>
  ),
  reports: (
    <>
      <path d="M3 3v18h18" />
      <path d="M7 15l4-5 3 3 5-7" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09A1.65 1.65 0 0 0 15 4.6a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z" />
    </>
  ),
};

// Which sidebar items each role can see — mirrors the permission matrix
// on Slide 3 of the requirement deck.
const NAV_BY_ROLE = {
  superadmin: ['dashboard', 'programs', 'add', 'reports', 'settings'],
  univadmin: ['dashboard', 'programs', 'add', 'reports', 'settings'],
  depthead: ['dashboard', 'programs', 'add', 'reports'],
  faculty: ['dashboard', 'programs'],
  student: ['dashboard', 'programs'],
  leadership: ['dashboard', 'reports'],
};

const NAV_ITEMS = [
  { key: 'dashboard', label: 'Dashboard', page: 'dashboard', icon: 'dashboard' },
  { key: 'programs', label: 'Programs', page: 'list', icon: 'programs' },
  { key: 'add', label: 'Add Program', page: 'add', icon: 'add' },
  { key: 'reports', label: 'Reports', page: 'reports', icon: 'reports' },
  { key: 'settings', label: 'Settings', page: 'settings', icon: 'settings' },
];

export default function Sidebar({ user, currentPage, navigateTo, isOpen, onClose }) {
  const allowed = NAV_BY_ROLE[user.role] || NAV_BY_ROLE.faculty;
  const roleMeta = getRoleMeta(user.role);
  const initials = (user.name || user.email || '?').trim().charAt(0).toUpperCase();

  return (
    <>
      {isOpen && <div className="lm-sidebar-backdrop" onClick={onClose} />}
      <aside className={`lm-sidebar ${isOpen ? 'lm-sidebar-open' : ''}`}>
        <div className="lm-sidebar-brand">
          <div className="lm-sidebar-logo">PM</div>
          <div className="lm-sidebar-brand-text">
            Program Manager
            <span>Academic Programs</span>
          </div>
        </div>

        <nav className="lm-sidebar-nav">
          {NAV_ITEMS.filter((item) => allowed.includes(item.key)).map((item) => (
            <button
              key={item.key}
              className={`lm-nav-item ${currentPage === item.page ? 'active' : ''}`}
              onClick={() => {
                navigateTo(item.page);
                onClose?.();
              }}
            >
              <svg viewBox="0 0 24 24">{icons[item.icon]}</svg>
              {item.label}
            </button>
          ))}
        </nav>

        <div className="lm-sidebar-footer">
          <div className="lm-role-pill">{roleMeta.label}</div>
          <div className="lm-sidebar-user">
            <div className="lm-avatar">{initials}</div>
            <div style={{ minWidth: 0 }}>
              <div className="lm-sidebar-user-name">{user.name}</div>
              <div className="lm-sidebar-user-email">{user.email}</div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}

export { NAV_BY_ROLE };
