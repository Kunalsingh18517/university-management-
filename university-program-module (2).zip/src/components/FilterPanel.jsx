import React from "react";

export default function FilterPanel({
  selectedDept,
  onDeptChange,
  selectedStatus,
  onStatusChange,
  departments,
}) {
  return (
    <div
      style={{
        display: "flex",
        gap: "20px",
        flexWrap: "wrap",
        alignItems: "flex-end",
        marginTop: "15px",
      }}
    >
      {/* Department Filter */}
      <div
        className="filter-group"
        style={{
          flex: "1",
          minWidth: "220px",
        }}
      >
        <label
          style={{
            display: "block",
            marginBottom: "8px",
            fontWeight: "600",
            color: "#374151",
          }}
        >
          🏫 Department
        </label>

        <select
          value={selectedDept}
          onChange={(e) => onDeptChange(e.target.value)}
          style={{
            width: "100%",
            padding: "12px",
            borderRadius: "10px",
            border: "1px solid #d1d5db",
            fontSize: "15px",
            background: "#fff",
            cursor: "pointer",
          }}
        >
          <option value="All">All Departments</option>

          {departments.map((dept) => (
            <option key={dept} value={dept}>
              {dept}
            </option>
          ))}
        </select>
      </div>

      {/* Status Filter */}
      <div
        className="filter-group"
        style={{
          flex: "1",
          minWidth: "220px",
        }}
      >
        <label
          style={{
            display: "block",
            marginBottom: "8px",
            fontWeight: "600",
            color: "#374151",
          }}
        >
          📌 Status
        </label>

        <select
          value={selectedStatus}
          onChange={(e) => onStatusChange(e.target.value)}
          style={{
            width: "100%",
            padding: "12px",
            borderRadius: "10px",
            border: "1px solid #d1d5db",
            fontSize: "15px",
            background: "#fff",
            cursor: "pointer",
          }}
        >
          <option value="All">All Status</option>
          <option value="Active">✅ Active</option>
          <option value="Inactive">⏸ Inactive</option>
          <option value="Archived">📦 Archived</option>
        </select>
      </div>
    </div>
  );
}