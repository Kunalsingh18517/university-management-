import React from "react";

const SearchBar = ({ searchTerm, onSearchChange }) => {
  return (
    <div
      className="search-bar"
      style={{
        display: "flex",
        alignItems: "center",
        gap: "12px",
        marginBottom: "20px",
        flexWrap: "wrap",
      }}
    >
      <div
        style={{
          position: "relative",
          flex: "1",
          minWidth: "250px",
        }}
      >
        <span
          style={{
            position: "absolute",
            left: "15px",
            top: "50%",
            transform: "translateY(-50%)",
            fontSize: "18px",
            color: "#6b7280",
          }}
        >
          🔍
        </span>

        <input
          type="text"
          placeholder="Search by Program Name, Code or Description..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="search-input"
          style={{
            width: "100%",
            padding: "14px 18px 14px 45px",
            border: "1px solid #d1d5db",
            borderRadius: "10px",
            outline: "none",
            fontSize: "15px",
            transition: "0.3s",
            background: "#fff",
          }}
        />
      </div>
    </div>
  );
};

export default SearchBar;