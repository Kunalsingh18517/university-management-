import React, { useState, useEffect } from 'react';
import { dummyBackendService } from '../services/dummyBackendService';

const PAGE_TITLES = {
  dashboard: 'Dashboard',
  list: 'Programs',
  add: 'Add Program',
  edit: 'Edit Program',
  details: 'Program Details',
  reports: 'Reports',
  settings: 'Settings',
};

function timeAgo(iso) {
  if (!iso) return '';
  const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

export default function Topbar({
  user,
  currentPage,
  navigateTo,
  onOpenSearch,
  onLogout,
  onToggleSidebar,
  canCreate,
}) {
  const [showMenu, setShowMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    if (!showNotifications) return;
    dummyBackendService
      .getAllIncludingArchived()
      .then((programs) => {
        const scoped =
          user.role === 'depthead' || user.role === 'student'
            ? programs.filter((p) => p.department === user.department)
            : programs;

        const items = [...scoped]
          .sort((a, b) => new Date(b.updatedAt || b.createdAt) - new Date(a.updatedAt || a.createdAt))
          .slice(0, 5)
          .map((p) => ({
            id: p.id,
            title:
              p.status === 'Archived'
                ? `${p.name} was archived`
                : `${p.name} was updated`,
            time: timeAgo(p.updatedAt),
          }));
        setNotifications(items);
      })
      .catch(() => setNotifications([]));
  }, [showNotifications, user]);

  return (
    <header className="lm-topbar">
      <button className="lm-icon-btn lm-hamburger" onClick={onToggleSidebar} aria-label="Open menu">
        <svg viewBox="0 0 24 24">
          <path d="M3 6h18M3 12h18M3 18h18" />
        </svg>
      </button>

      <div className="lm-breadcrumb">
        Home / <strong>{PAGE_TITLES[currentPage] || 'Dashboard'}</strong>
      </div>

      <div className="lm-topbar-search" onClick={onOpenSearch}>
        <svg viewBox="0 0 24 24">
          <circle cx="11" cy="11" r="7" />
          <path d="m21 21-4.3-4.3" />
        </svg>
        <span>Search for programs, departments...</span>
        <kbd>Ctrl K</kbd>
      </div>

      <div className="lm-topbar-actions">
        <div style={{ position: 'relative' }}>
          <button
            className="lm-icon-btn"
            aria-label="Notifications"
            onClick={() => {
              setShowNotifications((v) => !v);
              setShowMenu(false);
            }}
          >
            <svg viewBox="0 0 24 24">
              <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 0 1-3.46 0" />
            </svg>
            {notifications.length === 0 && <span className="lm-dot" />}
          </button>

          {showNotifications && (
            <div
              style={{
                position: 'absolute',
                right: 0,
                top: '44px',
                background: 'var(--surface)',
                border: '1px solid var(--line)',
                borderRadius: '10px',
                boxShadow: 'var(--shadow-md)',
                width: '280px',
                padding: '8px',
                zIndex: 200,
              }}
              onMouseLeave={() => setShowNotifications(false)}
            >
              <div style={{ padding: '6px 8px', fontSize: '12.5px', fontWeight: 700, color: 'var(--charcoal)' }}>
                Recent activity
              </div>
              {notifications.length === 0 ? (
                <div style={{ padding: '10px 8px', fontSize: '13px', color: 'var(--slate)' }}>
                  Nothing new right now.
                </div>
              ) : (
                notifications.map((n) => (
                  <div
                    key={n.id}
                    style={{
                      padding: '8px',
                      borderRadius: '7px',
                      cursor: 'pointer',
                      fontSize: '13px',
                    }}
                    onClick={() => {
                      navigateTo('details', n.id);
                      setShowNotifications(false);
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--parchment)')}
                    onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
                  >
                    <div style={{ color: 'var(--charcoal)' }}>{n.title}</div>
                    <div style={{ color: 'var(--slate)', fontSize: '11.5px', marginTop: '2px' }}>{n.time}</div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {canCreate && (
          <button className="lm-btn-new" onClick={() => navigateTo('add')}>
            <svg viewBox="0 0 24 24">
              <path d="M12 5v14M5 12h14" />
            </svg>
            New Entry
          </button>
        )}

        <div style={{ position: 'relative' }}>
          <button
            className="lm-avatar"
            style={{ border: 'none', cursor: 'pointer' }}
            onClick={() => setShowMenu((v) => !v)}
            aria-label="Account menu"
          >
            {(user.name || '?').trim().charAt(0).toUpperCase()}
          </button>

          {showMenu && (
            <div
              style={{
                position: 'absolute',
                right: 0,
                top: '44px',
                background: 'var(--surface)',
                border: '1px solid var(--line)',
                borderRadius: '10px',
                boxShadow: 'var(--shadow-md)',
                minWidth: '180px',
                padding: '8px',
                zIndex: 200,
              }}
              onMouseLeave={() => setShowMenu(false)}
            >
              <div style={{ padding: '8px 10px', fontSize: '13px', color: 'var(--slate)' }}>
                Signed in as<br />
                <strong style={{ color: 'var(--charcoal)' }}>{user.name}</strong>
              </div>
              <button
                className="lm-nav-item"
                style={{ color: 'var(--danger)' }}
                onClick={onLogout}
              >
                <svg viewBox="0 0 24 24">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                  <path d="M16 17l5-5-5-5M21 12H9" />
                </svg>
                Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
