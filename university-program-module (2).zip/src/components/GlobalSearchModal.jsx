import React, { useState, useEffect, useMemo } from 'react';
import { dummyBackendService } from '../services/dummyBackendService';

export default function GlobalSearchModal({ isOpen, onClose, navigateTo }) {
  const [query, setQuery] = useState('');
  const [programs, setPrograms] = useState([]);

  useEffect(() => {
    if (!isOpen) return;
    setQuery('');
    dummyBackendService.getAll().then(setPrograms).catch(() => setPrograms([]));
  }, [isOpen]);

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  const { matchedPrograms, matchedDepartments } = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) {
      return { matchedPrograms: programs.slice(0, 5), matchedDepartments: [] };
    }

    const progMatches = programs
      .filter(
        (p) =>
          p.name.toLowerCase().includes(term) ||
          p.code.toLowerCase().includes(term) ||
          (p.shortName || '').toLowerCase().includes(term) ||
          (p.coordinator || '').toLowerCase().includes(term)
      )
      .slice(0, 8);

    const deptSet = [...new Set(programs.map((p) => p.department))].filter((d) =>
      d.toLowerCase().includes(term)
    );

    return { matchedPrograms: progMatches, matchedDepartments: deptSet };
  }, [query, programs]);

  if (!isOpen) return null;

  const goTo = (page, id) => {
    navigateTo(page, id);
    onClose();
  };

  const hasResults = matchedPrograms.length > 0 || matchedDepartments.length > 0;

  return (
    <div className="lm-search-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="lm-search-modal">
        <div className="lm-search-input-row">
          <svg viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="7" />
            <path d="m21 21-4.3-4.3" />
          </svg>
          <input
            autoFocus
            type="text"
            placeholder="Search for programs, codes, coordinators, departments..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <span className="lm-search-esc" onClick={onClose}>esc</span>
        </div>

        <div className="lm-search-body">
          {matchedPrograms.length > 0 && (
            <>
              <div className="lm-search-section-label">Programs</div>
              {matchedPrograms.map((p) => (
                <div key={p.id} className="lm-search-result" onClick={() => goTo('details', p.id)}>
                  <div className="lm-search-result-icon">{p.code.slice(0, 2)}</div>
                  <div>
                    <div className="lm-search-result-title">{p.name}</div>
                    <div className="lm-search-result-sub">
                      {p.code} · {p.department} · {p.status}
                    </div>
                  </div>
                </div>
              ))}
            </>
          )}

          {matchedDepartments.length > 0 && (
            <>
              <div className="lm-search-section-label">Departments</div>
              {matchedDepartments.map((dept) => (
                <div key={dept} className="lm-search-result" onClick={() => goTo('list')}>
                  <div className="lm-search-result-icon">🏫</div>
                  <div>
                    <div className="lm-search-result-title">{dept}</div>
                    <div className="lm-search-result-sub">View programs in this department</div>
                  </div>
                </div>
              ))}
            </>
          )}

          {!hasResults && (
            <div className="lm-search-empty">
              {query ? `No results for "${query}".` : 'Start typing to search programs...'}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
