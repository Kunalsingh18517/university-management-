import React from "react";

export default function ProgramTable({
  programs,
  sortField,
  sortOrder,
  onSort,
  onView,
  onEdit,
  onDeleteTrigger,
  onRestore,
  canEdit = true,
  canDelete = true,
})  {
  if (programs.length === 0) {
    return (
      <div
        style={{
          textAlign: "center",
          padding: "40px",
          color: "#6b7280",
          fontSize: "18px",
        }}
      >
       <div
  style={{
    textAlign: "center",
    padding: "60px",
  }}
>

<h2>📂 No Programs Found</h2>

<p>
No program matches your current search or filter.
</p>

</div>
      </div>
    );
  }

  return (
    <div
      className="table-container"
      style={{
        overflowX: "auto",
        borderRadius: "15px",
      }}
    >
      <table
        className="program-table"
        style={{
          width: "100%",
          minWidth: "1080px",
          borderCollapse: "collapse",
          background: "#fff",
        }}
      >
       <thead
  style={{
    background: "var(--ink)",
    color: "#fff",
  }}
>
  <tr>

    <th
      style={{ cursor: "pointer" }}
      onClick={() => onSort("code")}
    >
      Code {sortField === "code" ? (sortOrder === "asc" ? "▲" : "▼") : ""}
    </th>

    <th
      style={{ cursor: "pointer" }}
      onClick={() => onSort("name")}
    >
      Program Name {sortField === "name" ? (sortOrder === "asc" ? "▲" : "▼") : ""}
    </th>

    <th
      style={{ cursor: "pointer" }}
      onClick={() => onSort("department")}
    >
      Department {sortField === "department" ? (sortOrder === "asc" ? "▲" : "▼") : ""}
    </th>

    <th>Coordinator</th>

    <th>Duration</th>

    <th>Capacity</th>

    <th>Enrolled</th>

    <th>Status</th>

    <th>Actions</th>

  </tr>
</thead>


        <tbody>
          {programs.map((program) => (
            <tr
              key={program.id}
              style={{
                transition: ".3s",
              }}
            >
              <td
                style={{
                  fontWeight: "600",
                  color: "var(--ink)",
                  fontFamily: "var(--font-mono)",
                }}
              >
                {program.code}
              </td>

              <td>{program.name}</td>

              <td>{program.department}</td>

              <td>{program.coordinator || '—'}</td>

              <td className="center">
                {program.duration} Years
              </td>

              <td className="center">
                {program.capacity}
              </td>

              <td className="center">
                {program.enrolled}
              </td>

              <td>
                <span
                  className={`status-badge status-${program.status.toLowerCase()}`}
                >
                  {program.status}
                </span>
              </td>

              <td className="actions">
                <button
                  className="btn-view"
                  onClick={() => onView(program.id)}
                >
                  👁 View
                </button>

                {program.isDeleted ? (
                  canDelete && (
                    <button
                      className="btn-view"
                      onClick={() => onRestore && onRestore(program.id)}
                    >
                      ♻ Restore
                    </button>
                  )
                ) : (
                  <>
                    {canEdit && (
                      <button
                        className="btn-edit"
                        onClick={() => onEdit(program.id)}
                      >
                        ✏ Edit
                      </button>
                    )}

                    {canDelete && (
                      <button
                        className="btn-delete"
                        onClick={() => onDeleteTrigger(program)}
                      >
                        📦 Archive
                      </button>
                    )}
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
